# Infrastructure Decisions

## Cloud provider
- Choose: AWS (recommended), GCP, or Azure
- Core infra:
  - EKS / GKE / AKS for container orchestration
  - S3 / GCS for blob storage
  - RDS (Postgres) for metadata
  - Elasticache (Redis) for caching
  - Vector DB: managed Pinecone or self-hosted Milvus on cluster nodes

## Networking
- Private VPC with service subnets
- Load balancer (ALB/NLB) in front of ingress
- VPC endpoints for S3

## IaC example (Terraform snippet)
See `terraform.tf` for a minimal local/dev snippet.
