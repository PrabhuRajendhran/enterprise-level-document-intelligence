# System Design — Component Details

## Orchestrator (API)
- FastAPI or Flask + Uvicorn/Gunicorn
- Responsibilities: Accept user queries, auth checks, orchestration of retrieval + model call, schema validation, response shaping.
- Performance: async endpoints, connection pooling to vector DB and model service.

## Retriever Service
- Split into:
  1. Indexing workers (ingest attachments, chunk, embed, upsert vectors)
  2. Query workers (compute query embedding, chunk-level retrieval)
- Vector DB options: FAISS (local), Milvus, Pinecone, Weaviate, Qdrant
- Use approximate nearest neighbor search (HNSW) and control ef/search param to tune latency/recall.

## Model (SLM) Service
- Host models via Kubernetes (KServe / Triton / Ray Serve) or use an external API (OpenAI/Anthropic).
- Provide:
  - Prompt templates per intent
  - Temperature & decoding config per request
  - Safety filters pre & post
- Cache responses for identical context-hash to reduce cost.

## Storage & Metadata
- Blob store (S3) for original documents and attachments
- Postgres for user metadata, access logs, conversation state
- Redis for rate-limiting, session store, short-term cache

## Observability & Ops
- Tracing: OpenTelemetry
- Metrics: Prometheus + Grafana dashboards
- Logs: structured JSON logs to ELK / Cloud logging
- Alerts: latency, error rate, vector DB health, model timeouts

## Security
- TLS everywhere
- Signed URLs for attachments
- Encryption at rest for S3/DB
- RBAC for internal services
