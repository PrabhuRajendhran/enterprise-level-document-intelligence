# Project Plan — Milestones & Tasks

## Milestones (12 weeks)
1. Week 0-1: Requirements & prototype plan
2. Week 2-3: Minimal Retriever + Indexer, local FAISS proof-of-concept
3. Week 4-5: Orchestrator + SLM integration (sandbox model)
4. Week 6-7: Storage, Auth, and Conversation state persistence
5. Week 8-9: Scaling vector DB (Milvus/Pinecone), add reranker
6. Week 10-11: Observability, security hardening, tests
7. Week 12: Production roll-out and runbook creation

## Example tasks (for Week 2)
- Build ETL: ingestion API, file parsers (pdf, docx, html)
- Chunker: sliding-window text splitter
- Embedding pipeline: batch and streaming variants
- Upsert: vector DB client + metadata schema

## Roles
- Product lead (1)
- ML engineer (2)
- Backend engineer (2)
- DevOps (1)
- QA & SRE (1)

## Risks & Mitigations
- Risk: high cost from model usage -> Mitigate: response caching, cheaper model for drafts.
- Risk: low retrieval quality -> Mitigate: hybrid retrieval and human-in-the-loop evaluations.
