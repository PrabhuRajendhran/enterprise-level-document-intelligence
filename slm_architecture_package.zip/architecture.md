# Architecture — SLM-based Chat Path + Retrieval

## Summary
This document describes an architecture for a Retrieval-Augmented Generation (RAG) system integrated with an SLM (supervised / specialized LLM) Chat Path and multi-tier retrieval and orchestration layers. The design aims for:
- Scalability
- Low-latency retrieval
- Modularity for model swapping and evaluation
- Observability and secure data flows

## High-level components
- Client (web/mobile)
- API Gateway / Edge
- Auth / IAM
- Orchestrator (FastAPI service)
- Retriever service (vector DB + retriever workers)
- Reranker (optional)
- SLM Model service (hosted models or external API)
- Post-processing & Formatter
- Logging, Telemetry, Metrics (Prometheus + Grafana)
- Storage: Blob store (S3), Metadata DB (Postgres), Vector DB (FAISS/Milvus/Pinecone)

## Data flow (mermaid)
```mermaid
%%{init: {'themeVariables': { 'fontFamily': 'Inter, Arial' }}}%%
graph TD
  Client -->|HTTP/WS| APIGW[API Gateway]
  APIGW --> Auth[Auth Service]
  APIGW --> Orch[Orchestrator Service]
  Orch --> Retriever[Retriever Service]
  Retriever -->|top-k docs| Reranker
  Reranker --> SLM[SLM Model Service]
  SLM --> Post[Post-processor]
  Post --> Client
  Retriever --> VectorDB[(Vector DB)]
  Orchestrator --> MetaDB[(Postgres Metadata DB)]
```

## Key design choices
- Vector DB: use FAISS for single-node dev, Milvus/Pinecone/Weaviate for production.
- Chunking: overlap 20-30% with 100-500 token chunk size.
- Embeddings: use an embeddings model with stable dimensionality (e.g., 1536 or 1024), persist vectors and metadata in vector DB.
- Retrieval pipeline: dense retrieval (embedding similarity) + sparse retrieval (BM25) optionally combined via hybrid queries.
- SLM: expose as an internal microservice that takes context + instructions and returns responses. Use model caching for repeated prompts.
- Safety: apply prompt sanitizer, hallucination checks, and guardrails via post-processing and classifier model.
