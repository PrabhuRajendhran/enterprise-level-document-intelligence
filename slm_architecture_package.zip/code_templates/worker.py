# Indexing worker example (worker.py)
import time
def chunk_text(text, chunk_size=500, overlap=100):
    tokens = text.split()
    out = []
    i = 0
    while i < len(tokens):
        chunk = tokens[i:i+chunk_size]
        out.append(" ".join(chunk))
        i += chunk_size - overlap
    return out

def embed_texts(texts):
    # placeholder - integrate embeddings model here
    return [[0.0]*768 for _ in texts]

def upsert_to_vector_db(vectors, metas):
    # placeholder: write to vector DB client
    time.sleep(0.1)

if __name__ == '__main__':
    sample = "This is a long document..." * 200
    chunks = chunk_text(sample)
    vecs = embed_texts(chunks)
    upsert_to_vector_db(vecs, [{"text": c} for c in chunks])
