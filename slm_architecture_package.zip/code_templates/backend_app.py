# FastAPI orchestrator skeleton (backend_app.py)
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import asyncio
import httpx

app = FastAPI(title="SLM Orchestrator")

class QueryRequest(BaseModel):
    user_id: str
    query: str
    k: int = 5

@app.post("/query")
async def query(q: QueryRequest):
    # 1. Validate + auth (omitted)
    # 2. Call retriever service
    async with httpx.AsyncClient(timeout=10) as client:
        resp = await client.post("http://retriever:8001/retrieve", json=q.dict())
        if resp.status_code != 200:
            raise HTTPException(status_code=502, detail="Retriever error")
        docs = resp.json()
    # 3. Call SLM model service with prompt template
    prompt = f"""You are a helpful assistant. Use the following documents to answer the query:\n{docs}\nQuery: {q.query}"""
    async with httpx.AsyncClient(timeout=30) as client:
        model_resp = await client.post("http://slm-model:8002/generate", json={"prompt": prompt, "max_tokens": 512})
        if model_resp.status_code != 200:
            raise HTTPException(status_code=502, detail="Model error")
        result = model_resp.json()
    return {"answer": result}
