# SLM-based Chat + Retrieval Architecture Package
This ZIP contains:
- Architecture document (architecture.md)
- System design (system_design.md)
- Project plan (project_plan.md)
- Infrastructure decisions (infra.md)
- Mermaid diagrams (mermaid_diagrams.mmd)
- Code templates (code_templates/)
- Deployment (docker-compose.yml, terraform.tf)

**How to use**
1. Inspect `architecture.md` and `system_design.md` for high-level and component details.
2. Use the `code_templates/` as starting points for each tier.
3. Adjust infra (terraform.tf) and docker-compose to your cloud provider and credentials.
